# Tecno Spark 40 → Samsung charging ring (LSPosed alpha)

**Status: source project, NOT device-tested or verified APK.** Prepared against the user-provided
Tecno KM6/Android 15 archive and Samsung SystemUI APK. For a rooted Samsung Galaxy S23
running One UI 9 / Android 17 with an operational LSPosed environment.

## What is included

- Real Tecno Spark 40 charging video converted into **transparent animated WebP frames**.
- 50 original frames for entry (0–49), then loop segments matching Tecno's config:
  - `loop_0.webp` → frames 50–99
  - `loop_1.webp` → frames 100–149
  - `loop_2.webp` → frames 150–199
  - `loop_3.webp` → frames 200–249
  - `loop_4.webp` → frames 300–349
  - `loop_5.webp` → frames 350–399
- The original video and XML for verifying/recreating animation in `reference/` (not included in APK).
- An LSPosed legacy-API module with default SystemUI scope; tries to hook two classes **confirmed
  in the provided Samsung SystemUI dex**:
  - `com.android.systemui.SystemUIApplication.onCreate`
  - `com.android.systemui.shade.NotificationShadeWindowView.onAttachedToWindow`
- Injects a transparent, non-clickable, temporary animation view on the shade/lock-screen view.
- Reads **real** system battery percentage from `ACTION_BATTERY_CHANGED`; no fake percentage.
- Shows on charge connection while keyguard is locked; hides on unplug, screen off, or after 8.5 seconds.
- Basic preview app usable without root.

## Build on GitHub Actions (no PC needed)

1. Extract this ZIP **with its folder structure intact**.
2. Put the contents into a NEW GitHub repository (do not overwrite your previous LSPosed project).
3. Open GitHub → repository → **Actions** → **Build LSPosed APK** → **Run workflow**.
4. After a successful build, open the action run and download the artifact:
   `Tecno-Spark40-Charge-LSPosed-debug-apk`.
5. Extract its `app-debug.apk` and install it on the Samsung. Debug APK will be signed by Gradle.

The workflow installs Java 17, Android SDK platform 35 and Gradle 8.11.1.
Never upload personal signing keys to a public repository.

## Termux local build (if Android SDK + Gradle already installed)

```bash
pkg install -y openjdk-17 git
# Set ANDROID_HOME to the directory where your Android SDK is installed.
# Example only: export ANDROID_HOME="$HOME/android-sdk"
# Android SDK platform 35 and build-tools 35.0.0 must be available.
gradle --no-daemon :app:assembleDebug
# APK at: app/build/outputs/apk/debug/app-debug.apk
```

Without an Android SDK + a compatible aapt2 for your phone's architecture,
local Termux builds may fail. The GitHub Actions workflow is the recommended route.

## Enable module

1. Install the newly built APK.
2. Open LSPosed Manager → Modules → **Tecno Spark 40 Charge**.
3. Enable it; scope **System UI (`com.android.systemui`) only**.
4. Restart SystemUI via a safe/reversible method, or reboot the phone.
5. Lock screen, then connect the charger and observe. Verify percentage updates and fingerprint/unlock behavior.
6. If any problem: disable module in LSPosed and reboot; the stock SystemUI APK was **not** replaced.

To inspect runtime logs: `logcat -s Spark40Charge:*` (root/appropriate log access may be needed).

## Known limitations

- **Not yet built or tested on the device**. One UI 9 / Android 17 behavior is experimental.
- The supplied Tecno MP4 is **25 FPS**. Transparent WebP loops preserve native frames;
  a 120 Hz phone screen does not make these 120 FPS.
- MP4 black pixels were converted to transparency to keep Samsung wallpaper visible.
  This is a visual transformation of the original video, not a byte-for-byte native HiOS renderer.
- Mode IDs in Tecno XML are not annotated by charging marketing names. The alpha chooses
  `loop_0` for standard charging, `loop_2` if reported max charging watts suggest fast
  charging, `loop_4` for wireless. Exact vendor-mode mapping cannot be verified yet.
- The `%` and lightning/text label are reimplemented with Samsung's live battery data;
  the screenshot's original emblem/font is not ported exactly yet.
- Some Samsung One UI skins may place the root view behind other lock-screen layers.
  If nothing appears, diagnose by logcat before modifying hooks. Do not replace SystemUI.apk.
- When charging begins with screen OFF, the module does **not** force-wake the device.
- No UI settings to control mode selection yet.
- The included `xposed-api-stubs.jar` is **compile-only**; LSPosed provides the real API at runtime.

## Source verification

- Tecno device ID from supplied extraction: `TECNO KM6`, Android 15.
- Original MP4: 1632×1088 H.264, 25 FPS, 400 frames / 16 seconds.
- XML `fileMd5`: `7b4891423cc5c4f117be16be04badd9f` matches the supplied MP4.
- Transparent WebP: 720×720 with 50 frames per segment, rendered from original video using black-colorkey.

**If Android shows "App not installed" due to conflicting signature**, do not uninstall
arbitrarily: check whether another app with the same package `dev.spark40.charge` is installed.
Uninstalling that package removes its settings; do not uninstall unrelated modules.
