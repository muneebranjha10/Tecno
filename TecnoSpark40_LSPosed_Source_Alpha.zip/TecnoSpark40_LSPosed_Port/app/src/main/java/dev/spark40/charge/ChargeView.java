package dev.spark40.charge;

import android.content.Context;
import android.content.Intent;
import android.graphics.ImageDecoder;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable2;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Build;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Transparently keyed frames derived from original HiOS MP4; no fake battery values. */
public final class ChargeView extends FrameLayout {
    private final ImageView ring;
    private final TextView percent;
    private final TextView chargeLabel;
    private final Context resourcesContext;
    private AnimatedImageDrawable animation;
    private boolean stopped;
    private boolean started;
    private int mode;

    public ChargeView(Context context) {
        super(context);
        resourcesContext = context;
        setClipChildren(true);
        setClipToPadding(false);
        setClickable(false);
        setFocusable(false);
        setBackgroundColor(0x00000000);

        ring = new ImageView(context);
        ring.setScaleType(ImageView.ScaleType.FIT_XY);
        ring.setClickable(false);
        ring.setFocusable(false);
        addView(ring);

        LinearLayout captions = new LinearLayout(context);
        captions.setOrientation(LinearLayout.VERTICAL);
        captions.setGravity(Gravity.CENTER);
        captions.setClickable(false);
        captions.setFocusable(false);
        percent = new TextView(context);
        percent.setGravity(Gravity.CENTER);
        percent.setTextColor(0xFFFFFFFF);
        percent.setTextSize(43);
        percent.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        percent.setIncludeFontPadding(false);
        percent.setText("—%");
        captions.addView(percent);
        chargeLabel = new TextView(context);
        chargeLabel.setGravity(Gravity.CENTER);
        chargeLabel.setTextColor(0xFFF8F8FA);
        chargeLabel.setTextSize(13);
        chargeLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        chargeLabel.setIncludeFontPadding(false);
        chargeLabel.setText("⚡ CHARGING");
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = dp(8);
        captions.addView(chargeLabel, labelParams);
        captions.setTag("charge-caption");
        addView(captions);
    }

    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        // Main Tecno ring is ~50% across and ~36% down the original crop.
        int size = Math.round(w * 1.17f);
        int top = Math.round(h * .38f - size * .36f);
        LayoutParams ringParams = new LayoutParams(size, size, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ringParams.topMargin = top;
        ring.setLayoutParams(ringParams);
        View captions = findViewWithTag("charge-caption");
        LayoutParams captionParams = new LayoutParams(w, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        captionParams.topMargin = Math.round(h * .38f) - dp(39);
        captions.setLayoutParams(captionParams);
    }

    public void updateBattery(Intent data) {
        if (data == null) return;
        int level = data.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = data.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scale > 0) {
            int battery = Math.min(100, Math.max(0, Math.round(level * 100f / scale)));
            String result = battery + "%";
            SpannableString s = new SpannableString(result);
            s.setSpan(new RelativeSizeSpan(.60f), result.length() - 1, result.length(), 0);
            percent.setText(s);
        }
        int plugged = data.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int maxCurrent = data.getIntExtra("max_charging_current", 0);
        int maxVoltage = data.getIntExtra("max_charging_voltage", 0);
        // Vendor reports are not guaranteed. Only show Fast Charge if supplied data suggests it.
        double watts = (maxCurrent > 0 && maxVoltage > 0)
                ? (maxCurrent / 1000000.0) * (maxVoltage / 1000000.0) : 0;
        if (plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS) {
            mode = 4;
            chargeLabel.setText("⚡ WIRELESS CHARGING");
        } else if (watts >= 15) {
            mode = 2;
            chargeLabel.setText("⚡ FAST CHARGE");
        } else {
            mode = 0;
            chargeLabel.setText("⚡ CHARGING");
        }
        // Mode changes after initial playback are supported; do not restart every battery tick.
    }

    public void start() {
        if (stopped || started) return;
        started = true;
        showAnimation("charge/entry.webp", false);
    }

    private void showAnimation(String asset, boolean looping) {
        if (stopped) return;
        try {
            if (animation != null) { animation.stop(); animation.clearAnimationCallbacks(); }
            Drawable loaded = ImageDecoder.decodeDrawable(ImageDecoder.createSource(
                    resourcesContext.getAssets(), asset));
            if (!(loaded instanceof AnimatedImageDrawable)) {
                ring.setImageDrawable(loaded);
                return;
            }
            animation = (AnimatedImageDrawable) loaded;
            animation.setRepeatCount(looping ? AnimatedImageDrawable.REPEAT_INFINITE : 0);
            ring.setImageDrawable(animation);
            if (!looping) {
                animation.registerAnimationCallback(new Animatable2.AnimationCallback() {
                    @Override public void onAnimationEnd(Drawable drawable) {
                        ring.post(() -> { if (!stopped) showAnimation("charge/loop_" + mode + ".webp", true); });
                    }
                });
            }
            animation.start();
        } catch (Throwable t) { Log.e("Spark40Charge", "Animation decoding failed: " + asset, t); }
    }

    public void stop() {
        stopped = true;
        if (animation != null) { animation.stop(); animation.clearAnimationCallbacks(); animation = null; }
        ring.setImageDrawable(null);
    }
}
