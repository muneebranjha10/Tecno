package dev.spark40.charge;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private ChargeView preview;
    private int previewGeneration;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout layout = new FrameLayout(this);
        layout.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF151B29, 0xFF081119, 0xFF070809}));
        setContentView(layout);

        preview = new ChargeView(this);
        layout.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        preview.updateBattery(sticky);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(26), dp(20), dp(26), dp(40));
        FrameLayout.LayoutParams box = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        layout.addView(controls, box);

        TextView heading = new TextView(this);
        heading.setText("TECNO  /  SPARK 40");
        heading.setTextSize(21);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setTextColor(Color.WHITE);
        controls.addView(heading);
        TextView desc = new TextView(this);
        desc.setText("Original charging ring • LSPosed alpha port\nEnable SystemUI scope in LSPosed, then restart SystemUI or reboot.\nPreview works without root; lock-screen trigger requires LSPosed.");
        desc.setTextSize(13);
        desc.setTextColor(0xFFB1C2D2);
        desc.setPadding(0, dp(8), 0, dp(18));
        controls.addView(desc);
        Button button = new Button(this);
        button.setText("Play preview");
        button.setOnClickListener(v -> {
            ++previewGeneration;
            final int token = previewGeneration;
            preview.stop();
            layout.removeView(preview);
            controls.setVisibility(View.INVISIBLE);
            preview = new ChargeView(this);
            layout.addView(preview, 0, new FrameLayout.LayoutParams(-1,-1));
            preview.updateBattery(registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
            preview.start();
            final ChargeView playing = preview;
            layout.postDelayed(() -> {
                if (token != previewGeneration) return;
                playing.stop();
                controls.setVisibility(View.VISIBLE);
            }, 8500);
        });
        controls.addView(button);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    @Override protected void onDestroy() { if (preview != null) preview.stop(); super.onDestroy(); }
}
