package dev.spark40.charge;

import android.app.Application;
import android.util.Log;
import android.view.ViewGroup;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Hooks are limited to Samsung's SystemUI process; no framework modification. */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "Spark40Charge";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)
                || !"com.android.systemui".equals(lpparam.processName)) return;

        try {
            XposedHelpers.findAndHookMethod("com.android.systemui.SystemUIApplication",
                    lpparam.classLoader, "onCreate", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                ChargeController.install((Application) param.thisObject);
                            } catch (Throwable t) { Log.e(TAG, "Install failed", t); }
                        }
                    });
        } catch (Throwable t) { Log.e(TAG, "Application hook unavailable", t); }

        // This exact class + override were found in the supplied Samsung SystemUI dex.
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.systemui.shade.NotificationShadeWindowView",
                    lpparam.classLoader, "onAttachedToWindow", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try { ChargeController.attach((ViewGroup) param.thisObject); }
                            catch (Throwable t) { Log.e(TAG, "View attach failed", t); }
                        }
                    });
        } catch (Throwable t) { Log.e(TAG, "Keyguard view hook unavailable", t); }
    }
}
