package dev.spark40.charge;

import android.app.Application;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.lang.ref.WeakReference;

/** All UI work stays on SystemUI's main thread. No extra overlay window or root shell. */
public final class ChargeController {
    private static final String TAG = "Spark40Charge";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final long DISPLAY_MS = 8500L;
    private static final long PENDING_MS = 12000L;

    private static Application app;
    private static Intent batteryIntent;
    private static WeakReference<ViewGroup> host = new WeakReference<>(null);
    private static ChargeView current;
    private static long lastConnectTime;
    private static int generation;

    private ChargeController() { }

    public static void install(Application application) {
        MAIN.post(() -> {
            if (app != null) return;
            app = application;
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_POWER_CONNECTED);
            filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            try {
                Intent initial;
                if (Build.VERSION.SDK_INT >= 33) {
                    initial = app.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
                } else {
                    initial = app.registerReceiver(receiver, filter);
                }
                if (initial != null && Intent.ACTION_BATTERY_CHANGED.equals(initial.getAction())) {
                    batteryIntent = initial;
                }
                Log.i(TAG, "Receiver installed in SystemUI");
            } catch (Throwable t) { Log.e(TAG, "Broadcast registration failed", t); }
        });
    }

    public static void attach(ViewGroup view) {
        MAIN.post(() -> {
            host = new WeakReference<>(view);
            if (lastConnectTime > 0 && SystemClock.elapsedRealtime() - lastConnectTime < PENDING_MS) show();
        });
    }

    private static final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                batteryIntent = intent;
                if (current != null) current.updateBattery(intent);
            } else if (Intent.ACTION_POWER_CONNECTED.equals(action)) {
                lastConnectTime = SystemClock.elapsedRealtime();
                show();
            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(action)
                    || Intent.ACTION_SCREEN_OFF.equals(action)) {
                hide();
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                if (lastConnectTime > 0 && SystemClock.elapsedRealtime() - lastConnectTime < PENDING_MS) show();
            }
        }
    };

    private static void show() {
        MAIN.post(() -> {
            try {
                if (app == null) return;
                ViewGroup root = host.get();
                if (root == null || !root.isAttachedToWindow()) return;
                KeyguardManager kg = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
                if (kg == null || !kg.isKeyguardLocked()) return;
                hideNow();
                Context moduleContext = app.createPackageContext("dev.spark40.charge", 0);
                ChargeView display = new ChargeView(moduleContext);
                display.setClickable(false);
                display.setFocusable(false);
                display.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                root.addView(display, lp);
                display.bringToFront();
                current = display;
                display.updateBattery(batteryIntent);
                display.setAlpha(0f);
                display.animate().alpha(1f).setDuration(220).start();
                display.start();
                final int token = ++generation;
                MAIN.postDelayed(() -> { if (generation == token) hide(); }, DISPLAY_MS);
            } catch (Throwable t) { Log.e(TAG, "Show failed", t); hideNow(); }
        });
    }

    private static void hide() {
        MAIN.post(() -> {
            if (current == null) return;
            final ChargeView view = current;
            current = null;
            ++generation;
            view.animate().alpha(0f).setDuration(180).withEndAction(() -> remove(view)).start();
        });
    }

    private static void hideNow() {
        if (current != null) {
            current.animate().cancel();
            remove(current);
            current = null;
        }
        ++generation;
    }

    private static void remove(ChargeView view) {
        view.stop();
        if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view);
    }
}
